 COPYRIGHT NOTICE:

 ALL FILES ARE COPYRIGHT (C) 2008,2009,2010 MONEV SOFTWARE LLC (EXCEPT WHERE NOTED), ALL RIGHTS RESERVED.

 Please notice some files are subject to GPL license and are noted as such in their source code.
 
 For files not identified as licensed under GPL:

 You shall not modify, copy, duplicate, reproduce, sell, license or
 sublicense the Software, or transfer or convey the Software or
 any right in the Software to anyone else without the prior
 written consent of Monev Software LLC; provided that Licensee may make
 one copy of the Software for backup or archival purposes.

Monev Software LLC
www.joomlaxtc.com